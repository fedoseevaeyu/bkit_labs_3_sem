﻿namespace Lab3.Figures
{
    class NullFigure : Figure
    {
        public override string ToString() => "0";
    }
}