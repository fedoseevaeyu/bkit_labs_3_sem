﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lab7.Models2;


namespace Lab7
{
    class Program
    {
        

        static void Main()
        {
           
            var model = new Model1Container();
            var Workers = (from Employee in model.EmployeeSet select Employee).ToList();
            var Departments = (from Department in model.DepartmentSet select Department).ToList();

            // Tasks

            Console.WriteLine("\nВыведите список всех сотрудников и отделов, отсортированный по отделам.");
            Console.WriteLine("ID) Department Name | ID) Surname");
            foreach (var dep in Departments.OrderBy(e => e.Name))
            {
                Console.WriteLine($"Department: {dep.Name}");
                foreach (var worker in dep.Employee)
                {
                    Console.WriteLine($"{worker.Surname}");
                }
                Console.WriteLine();
            }

            Console.WriteLine("\nВыведите список всех сотрудников, у которых фамилия начинается с буквы «А».");
            Console.WriteLine("ID) Surname"); 
            foreach (var worker in Workers.Where(w => w.Surname.ToUpper().StartsWith("A")))
            {
                Console.WriteLine($"{worker.Id}) {worker.Surname}");
            }

            Console.WriteLine("\nВыведите список всех отделов и количество сотрудников в каждом отделе.");
            Console.WriteLine();
            foreach (var dep in Departments)
            {
                Console.WriteLine($"Department: {dep.Name} -> {dep.Employee.Count} worker.");
            }

            Console.WriteLine("\nВыведите список отделов, в которых у всех сотрудников фамилия начинается с буквы «А».");
            Console.WriteLine("ID) Department Name");
            foreach (var dep in Departments
                .Where(x => x.Employee.All(y => y.Surname.ToUpper().StartsWith("A"))))
            {
                Console.WriteLine($"{dep.Id}) {dep.Name}");
            }

            Console.WriteLine("\nВыведите список отделов, в которых хотя бы у одного сотрудника фамилия начинается с буквы «А».");
            Console.WriteLine("ID) Department Name");
            foreach (var dep in Departments
                .Where(x => x.Employee.Any(y => y.Surname.ToUpper().StartsWith("A"))))
            {
                Console.WriteLine($"{dep.Id}) {dep.Name}");
            }


            Console.ReadLine();
        }
    }
}
